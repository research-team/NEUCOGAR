from api_initialisation import *
from api_connections import *
#from api_diagrams import *

from build_structure import *
from parameters import *
from data import *

SetKernelStatus(local_num_threads=52,
                data_path='txt')

InitNeuronModel(HH_COND_EXP_TRAUB, neuron_model_name, iaf_neuronparams)

InitSynapseModel(Glu, STDP_MODEL, stdp_glu_params)
InitSynapseModel(GABA, STDP_MODEL, stdp_gaba_params)
InitSynapseModel(DOPA_ex, STDP_DOPA_MODEL, stdp_dopa_ex_params, vt=True)
InitSynapseModel(DOPA_in, STDP_DOPA_MODEL, stdp_dopa_in_params, vt=True)

GenerateStructure(350000)

Connect(motor[motor_Glu0], striatum[D1], neurotransmitter=Glu, weight=0.08, stdp=False) # 0.08 < X < 0.1
Connect(motor[motor_Glu0], striatum[D2], neurotransmitter=Glu, weight=0.5, stdp=False)  # ? < X < 0.7
Connect(motor[motor_Glu0], stn[stn_Glu], neurotransmitter=Glu, weight=0.017)            # 0.01[X] < [] < 0.03
Connect(motor[motor_Glu0], thalamus[thalamus_Glu], neurotransmitter=Glu, weight=0.2)    # ? < X < 0.15 #0.25

Connect(striatum[D1], snr[snr_GABA], weight=0.0005) # 0.0001
Connect(striatum[D1], gpi[gpi_GABA], weight=0.0005) # 0.0001
Connect(striatum[D2], gpe[gpe_GABA], weight=0.3)   # 0.2

Connect(gpe[gpe_GABA], stn[stn_Glu], weight=3.) # 1.0 3.0

Connect(stn[stn_Glu], snr[snr_GABA], neurotransmitter=Glu, weight=0.5) # 0.2 0.7
Connect(stn[stn_Glu], gpi[gpi_GABA], neurotransmitter=Glu, weight=0.5) # 0.2 0.7

Connect(gpi[gpi_GABA], thalamus[thalamus_Glu], weight_coef=0.2) # 0.3
Connect(snr[snr_GABA], thalamus[thalamus_Glu], weight_coef=0.2) # 0.3

Connect(thalamus[thalamus_Glu], motor[motor_Glu1], neurotransmitter=Glu, weight=0.1) # 0.1

Connect(snc[snc_DA], striatum[D1], neurotransmitter=DOPA_ex, weight_coef=0.6) # 0.5
Connect(snc[snc_DA], striatum[D2], neurotransmitter=DOPA_in, weight_coef=0.6) # 0.5
Connect(vta[vta_DA], striatum[D1], neurotransmitter=DOPA_ex, weight_coef=0.6) # 0.5
Connect(vta[vta_DA], striatum[D2], neurotransmitter=DOPA_in, weight_coef=0.6) # 0.5


ConnectPoissonGenerator(motor[motor_Glu0], stop=T, rate=200, conn_percent=100, weight=w_Glu)
ConnectPoissonGenerator(gpe[gpe_GABA], stop=T, rate=600, conn_percent=100, weight=w_Glu) # 600 
ConnectPoissonGenerator(snc[snc_DA], start=400, stop=600, rate=500, conn_percent=100, weight=w_Glu) # 500
ConnectPoissonGenerator(vta[vta_DA], start=400, stop=600, rate=500, conn_percent=100, weight=w_Glu) # 500


ConnectDetector(striatum[D1])
ConnectDetector(striatum[D2])
ConnectDetector(gpi[gpi_GABA])
ConnectDetector(snr[snr_GABA])
ConnectMultimeter(snr[snr_GABA])
ConnectDetector(snc[snc_DA])
ConnectDetector(gpe[gpe_GABA])
ConnectDetector(thalamus[thalamus_Glu])
ConnectDetector(motor[motor_Glu0])
ConnectDetector(stn[stn_Glu])
ConnectDetector(motor[motor_Glu1])

Simulate(T)
