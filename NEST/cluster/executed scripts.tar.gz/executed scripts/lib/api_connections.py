__author__  = "Alexey Panzer"
__version__ = "1.7.1"
__tested___ = "14.08.2017 NEST 2.12.0 Python 3"

import api_globals as glob

logger = glob.logging.getLogger('api_connections')


def SetSynapseMaxNumber(maximal, part=None):
    if part is not None:
        glob.synapse_number_limitation[part[glob.k_name]] = maximal
    else:
        glob.max_syn_per_nrn = maximal


def Connect(pre, post, neurotransmitter=glob.GABA, weight=None, weight_coef=1., rec_weight=False, stdp=True):
    """
    Establish a connection between two nodes or lists of nodes
    
    Description:
        Redefine weight, connection number with limit checking, setup parameters and invoke nest origin method
    
    Args:
        pre (list): neurons GIDs of origin part
        post (list): neurons GIDs of target part
        neurotransmitter (int): key of a neurotrasmitter
        weight_coef (float): coeficient of transmitter concetration (weight)
    """


    # Correlate number of synapses
    if weight is None:
        new_weight = weight_coef * glob.synapse_models[neurotransmitter][glob.basic_weight]
    else:
        new_weight = weight

    current_synapses = glob.max_syn_per_nrn if post[glob.k_NN] > glob.max_syn_per_nrn else post[glob.k_NN]

    #if current_synapses > glob.max_syn_per_nrn:
    #    current_synapses = glob.max_syn_per_nrn
    #else:
    #    current_synapses = len(post[glob.k_NN])
    # Update number of synapses

    created_synapses = current_synapses * pre[glob.k_NN]

    glob.synapse_number += created_synapses

    # Create dictionary of connection rules
    conn_spec = {'rule': 'fixed_outdegree',
                 'outdegree': current_synapses,
                 'multapses': glob.multapses,  # multiple connections between a pair of nodes
                 'autapses': glob.autapses}  # self-connections
    build_params = {
            'model': glob.synapse_models[neurotransmitter][glob.model] if stdp else "static_synapse",
            'delay': {'distribution': 'uniform',
                      'low': 1.,
                      'high': 2.5},
            'weight': new_weight
        }

    if rec_weight:
        # Set number of recording neurons
        rec_nrn_number = 5
        # Create weight recorder with parameters
        weight_recorder = glob.nest.Create('weight_recorder', 1, {'to_memory': False,
                                                                  'to_file': True,
                                                                  'label': '{}_{}'.format(pre[glob.k_name], post[glob.k_name])})
        # Connect neuron IDs (rec_nrn_number, N] in normal mode without weight recorder
        glob.nest.Connect(pre[glob.k_IDs][rec_nrn_number:],
                          post[glob.k_IDs][rec_nrn_number:],
                          conn_spec=conn_spec,
                          syn_spec=build_params)

        # Create new model of synapse where added weight recorder ID in params

        #glob.nest.CopyModel('static_synapse',#glob.synapse_models[neurotransmitter][glob.model],
        #                    'rec_synapse',
        #                    {'weight_recorder': weight_recorder[0]})
        # Connect neuron IDs [0, rec_nrn_number] with weight recorder

        build_params['weight_recorder'] = weight_recorder[0]
        conn_spec['outdegree'] = rec_nrn_number
        glob.nest.Connect(pre[glob.k_IDs][:rec_nrn_number],
                          post[glob.k_IDs][:rec_nrn_number],
                          conn_spec=conn_spec,
                          syn_spec=build_params)
    else:
        # Connect neurons in the normal mode
        glob.nest.Connect(pre[glob.k_IDs],
                          post[glob.k_IDs],
                          conn_spec=conn_spec,
                          syn_spec=build_params)

    big = glob.nest.GetStatus(glob.nest.GetConnections( pre[glob.k_IDs][:2], post[glob.k_IDs][:2] ))
    print("- " * 30)
    print(pre[glob.k_name], "-->", post[glob.k_name])
    for i in big:
        print(i)
    print(stdp)
    print(build_params)
    print()

    #synapse_mem_usage = (created_synapses * glob.MEM_PER_SYNAPSE) >>  20
    synapse_mem_usage = round( (created_synapses * glob.MEM_PER_SYNAPSE) / (1024**2), 2)
    glob.syn_mem_usage += synapse_mem_usage

    # Show data of a new connection
    logger.info('{0} ({1:,}) to {2} ({3:,}). ({4:,} synapses = {5} MB 1:{6}). Weight={7} (x{8}) {9}'.format(
        pre[glob.k_name],                   # 0
        pre[glob.k_NN],                     # 1
        post[glob.k_name],                  # 2
        post[glob.k_NN],                    # 3
        created_synapses,                   # 5
        synapse_mem_usage,                  # 6
        current_synapses,                   # 7
        new_weight,                         # 8
        weight_coef,                        # 9
        "[+w_rec]" if rec_weight else ""    # 10
    ))

    del build_params


def ConnectVolumeTransmitters(*args):
    for part in args:
        print(part[glob.k_name])

def ConnectPoissonGenerator(part, start=0.1, stop=9999999, rate=250, conn_percent=100, weight=None):
    """
    Poisson_generator - simulate neuron firing with Poisson processes statistics.
    
    Description:    
        The poisson_generator simulates a neuron that is firing with Poisson statistics, i.e. exponentially 
        distributed interspike intervals. It will generate a _unique_ spike train for each of it's targets. 
        If you do not want this behavior and need the same spike train for all targets, you have to use a  
        parrot neuron inbetween the poisson generator and the targets.  
  
    Args:
        part         (array): IDs of neurons 
        start       (double): begin of device application with resp. to origin in ms  
        stop	    (double): end of device application with resp. to origin in ms
        rate	    (double): mean firing rate in Hz  
        probability (double): percent of connection probability
        weight      (double): strength of a signal (nS)
    """

    outdegree = int(part[glob.k_NN] * conn_percent / 100)

    generator = glob.nest.Create('poisson_generator', 1, {'rate' : float(rate),
                                                          'start': float(start),
                                                          'stop' : float(stop)})
    conn_spec = {'rule': 'fixed_outdegree',
                 'outdegree': outdegree}
    syn_spec = {
        'weight': float(weight),
        'delay': float(glob.pg_delay)}

    glob.nest.Connect(generator, part[glob.k_IDs], conn_spec=conn_spec, syn_spec=syn_spec)

    logger.info("(ID:{0}) to {1} ({2}/{3}). Interval: {4}-{5}ms".format(
        generator[0],
        part[glob.k_name],
        outdegree,
        part[glob.k_NN],
        start,
        stop
    ))


def ConnectDetector(part, detect=glob.N_detect):
    """
    bla bla
    
    Description:
        blabla
    
    Args:
        part (array): brain part
        detect (int): number of neurons which will be under detector watching
    """

    name = part[glob.k_name]
    detector_param = {'label': name,
                      'withgid': True,
                      'to_file': True,
                      'to_memory': False} #withweight true

    number = part[glob.k_NN] if part[glob.k_NN] < detect else detect
    tracing_ids = part[glob.k_IDs][:number]
    detector = glob.nest.Create('spike_detector', params=detector_param)
    glob.nest.Connect(tracing_ids, detector)
    logger.info("(ID:{0}) to {1} ({2}/{3})".format(detector[0], name, len(tracing_ids), part[glob.k_NN]))


def ConnectMultimeter(part, **kwargs):
    """
    la bla
    
    Description:
        blalala
    
    Args:
        part (array): neurons GIDs of a brain part
        ....
        ....
        ....
    """
    name = part[glob.k_name]
    multimeter_param = {'label': name,
                        'withgid': True,
                        'withtime': True,
                        'to_file': True,
                        'to_memory': False,
                        'interval': 0.1,
                        'record_from': ['V_m']}
    tracing_ids = part[glob.k_IDs][:glob.N_volt]
    multimeter = glob.nest.Create('multimeter', params=multimeter_param)  # ToDo add count of multimeters
    glob.nest.Connect(multimeter, tracing_ids)
    logger.info("(ID:{0}) to {1} ({2}/{3}: {4})".format(multimeter[0], name, len(tracing_ids), part[glob.k_NN], tracing_ids))
