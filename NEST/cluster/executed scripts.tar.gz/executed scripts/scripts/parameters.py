from api_globals import *
import random

""" Synapses """
# Synapse weights
w_Glu = 50.
w_GABA = -w_Glu * 1.5
w_DA_ex = 70.
w_DA_in = -w_DA_ex

T = 1000.

# Neuron parameters
iaf_neuronparams = {'V_m': -70.0,
                    'E_L': -70.0,
                    'E_K': -90.0,
                    'g_L': 30.0,
                    'g_Na': 12000.0,
                    'g_K': 3600.0,
                    'C_m': 134.0,
                    'tau_syn_ex': 0.2,
                    'tau_syn_in': 2.0
                    }

stdp_glu_params = {'weight': w_Glu,
                   'alpha': 1.0,
                   'lambda': 0.01,
		   'Wmax': 100.0,
                   'mu_plus': 0.1,
                   'mu_minus': 0.1
                   }

stdp_gaba_params = {'weight': w_GABA,
                    'alpha': 1.0,  
                    'lambda': 0.01,
                    'Wmax': -100.,
                    'mu_plus': 0.1,
       	       	    'mu_minus': 0.1
                    }

stdp_dopa_ex_params = {'weight': w_DA_ex,
                       'Wmax': 100.,
                       'Wmin': 0.1
                       }

stdp_dopa_in_params = {'weight': w_DA_in,
                       'Wmax': -0.1,
                       'Wmin': -100.
                       }
