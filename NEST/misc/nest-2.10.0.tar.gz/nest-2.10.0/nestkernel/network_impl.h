/*
 *  network_impl.h
 *
 *  This file is part of NEST.
 *
 *  Copyright (C) 2004 The NEST Initiative
 *
 *  NEST is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  NEST is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with NEST.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#ifndef NETWORK_IMPL_H
#define NETWORK_IMPL_H

#include "network.h"
#include "conn_builder.h"
#include "conn_builder_factory.h"
#include "growth_curve.h"
#include "growth_curve_factory.h"

template < typename ConnBuilder >
void
nest::Network::register_conn_builder( const std::string& name )
{
  assert( !connruledict_->known( name ) );
  GenericConnBuilderFactory* cb = new ConnBuilderFactory< ConnBuilder >();
  assert( cb != 0 );
  const int id = connbuilder_factories_.size();
  connbuilder_factories_.push_back( cb );
  connruledict_->insert( name, id );
}

template < typename GrowthCurve >
void
nest::Network::register_growth_curve( const std::string& name )
{
  assert( !growthcurvedict_->known( name ) );
  GenericGrowthCurveFactory* gc = new GrowthCurveFactory< GrowthCurve >();
  assert( gc != 0 );
  const int id = growthcurve_factories_.size();
  growthcurve_factories_.push_back( gc );
  growthcurvedict_->insert( name, id );
}

#endif
