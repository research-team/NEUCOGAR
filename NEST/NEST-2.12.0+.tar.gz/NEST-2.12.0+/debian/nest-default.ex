# Defaults for nest initscript
# sourced by /etc/init.d/nest
# installed at /etc/default/nest by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
