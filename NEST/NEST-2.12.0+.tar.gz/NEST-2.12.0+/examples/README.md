# `examples` folder

Examples for the usage of SLI and NEST. The examples for PyNEST can be found in the pynest directory. All examples are installed to the directory `$prefix/share/doc/nest/examples`.
